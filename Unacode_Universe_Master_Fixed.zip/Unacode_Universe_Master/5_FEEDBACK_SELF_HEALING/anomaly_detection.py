def detect_anomalies():
    print("Detecting anomalies across all verticals")
def log_audit(event):
    print(f"Audit Log: {event}")
# Unacode Execution Flow
1. Load wallet & Bitcoin proof
2. Run vertical workflows
3. Activate Infinity Genius AI
4. Detect anomalies and self-heal
5. Log audits
6. Publish NFT verification & dashboards
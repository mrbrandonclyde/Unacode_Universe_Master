interface IGodOversight {
    function reportTransaction(bytes32 txHash) external;
    function verifySignature(address user, string calldata signedMessage, string calldata signature) external returns(bool);
    function triggerSelfHealing(bytes32 anomalyId) external;
}
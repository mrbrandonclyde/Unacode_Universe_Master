// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;
import "@openzeppelin/contracts/token/ERC721/ERC721.sol";
import "@openzeppelin/contracts/access/Ownable.sol";
contract BitcoinProofNFT is ERC721, Ownable {
    uint256 public tokenCounter;
    mapping(uint256 => string) public tokenMetadataHash;
    constructor() ERC721("BitcoinProofNFT", "BTC-PROOF") { tokenCounter = 1; }
    function mintProof(address to, string memory proofHash) public onlyOwner {
        uint256 tokenId = tokenCounter;
        _safeMint(to, tokenId);
        tokenMetadataHash[tokenId] = proofHash;
        tokenCounter++;
    }
    function verifyProof(uint256 tokenId) public view returns (string memory) {
        return tokenMetadataHash[tokenId];
    }
}
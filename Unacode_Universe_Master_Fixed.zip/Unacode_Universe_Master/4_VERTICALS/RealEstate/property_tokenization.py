def tokenize_properties(wallet):
    print(f"Tokenizing properties for wallet {wallet}")
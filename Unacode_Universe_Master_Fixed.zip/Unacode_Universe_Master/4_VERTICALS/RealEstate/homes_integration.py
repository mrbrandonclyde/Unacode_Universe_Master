def update_homes_com(wallet):
    print(f"Syncing properties for wallet {wallet} to Homes.com")
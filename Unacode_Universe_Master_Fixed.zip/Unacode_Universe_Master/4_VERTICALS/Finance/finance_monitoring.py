def monitor_finance(wallet):
    print(f"Monitoring Finance for wallet {wallet}")
def sync_devices(wallet):
    print(f"Syncing IoT devices for wallet {wallet}")
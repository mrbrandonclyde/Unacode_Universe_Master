def verify_nft(token_id):
    print(f"Verifying NFT {token_id}")
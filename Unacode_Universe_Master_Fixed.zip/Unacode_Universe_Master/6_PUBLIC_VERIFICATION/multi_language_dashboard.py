def dashboard():
    print("Displaying dashboard in all languages")
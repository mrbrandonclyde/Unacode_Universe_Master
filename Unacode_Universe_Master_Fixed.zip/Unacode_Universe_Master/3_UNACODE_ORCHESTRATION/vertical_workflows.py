import logging

def run_verticals(wallet, proof):
    verticals = [
        ("Finance", "Finance.finance_monitoring"),
        ("Real Estate", "RealEstate.homes_integration"),
        ("Marketplaces", "Marketplaces.nft_sales_automation"),
        ("Media", "Media.media_ip_licensing"),
        ("Metaverse", "Metaverse.vr_4d_assets"),
        ("AI", "AI.ai_monitoring"),
        ("IoT", "IoT.iot_device_sync")
    ]

    for name, module_path in verticals:
        try:
            logging.info(f"Activating {name} Vertical")
            module = __import__(module_path, fromlist=[''])
            # Assume each module has a standard function named according to vertical
            func_name = module_path.split('.')[-1]
            getattr(module, func_name.split('_')[0] + '_' + func_name.split('_')[1])()
        except Exception as e:
            logging.error(f"{name} Vertical Error: {e}")
            print(f"{name} Vertical Error: {e}")

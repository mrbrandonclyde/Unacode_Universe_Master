def activate_ai():
    print("Infinity Genius AI is online")
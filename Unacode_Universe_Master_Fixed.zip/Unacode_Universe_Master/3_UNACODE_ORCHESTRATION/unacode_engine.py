import os
import logging
from dotenv import load_dotenv

load_dotenv()
ETH_WALLET = os.getenv("ETH_WALLET")
BITCOIN_PROOF = os.getenv("BITCOIN_PROOF")

if not ETH_WALLET or not BITCOIN_PROOF:
    raise ValueError("Missing wallet or Bitcoin proof in .env")

# Setup logging
logging.basicConfig(filename='10_LOGS/unacode_engine.log', level=logging.INFO,
                    format='%(asctime)s:%(levelname)s:%(message)s')

from vertical_workflows import run_verticals
from infinity_genius import activate_ai

def main():
    logging.info("Starting Unacode Universe Engine")
    logging.info(f"Ethereum Wallet Loaded")
    logging.info(f"Bitcoin Proof Loaded")
    run_verticals(ETH_WALLET, BITCOIN_PROOF)
    activate_ai()

if __name__ == "__main__":
    main()
